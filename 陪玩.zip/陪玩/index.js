// =============================================================
// index.js - v4.2c-Pink (v4.2b-Pink 基础上新增：开机自动检测并发送派单统计中心面板)
// 变更说明：
// - 在 client.once("ready") 中增加自动检测 LOG_CHANNEL_ID 是否存在 "📊 派单统计中心" embed
// - 若不存在则自动发送统计 embed + 按钮（粉色可爱风）
// 其它：继承 v4.2b-Pink 的 UI 与功能（移除关键词自动回复）
// =============================================================

// ---------------- IMPORTS ----------------
const {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  SlashCommandBuilder,
  REST,
  Routes,
  PermissionFlagsBits,
  ChannelType,
  AttachmentBuilder,
} = require("discord.js");
const fs = require("fs");
const XLSX = require("xlsx");
const axios = require("axios");
const FormData = require("form-data");

// ---------------- CONFIG ----------------
let config = {};
try {
  config = JSON.parse(fs.readFileSync("./config.json", "utf8"));
} catch (err) {
  console.error("❌ 无法读取 config.json", err);
  process.exit(1);
}

// ---------------- CONSTANTS ----------------
const TICKET_CATEGORY_ID = "1434345592997548033";
const SUPPORT_CATEGORY_ID = "1433718201690357808";
const SUPPORT_SECOND_ROLE_ID = "1434475964963749909";
const LOG_CHANNEL_ID = "1436268020866617494"; // 统计频道
const AUTO_REPORTBB_CHANNEL = "1436684853297938452";

const STATS_PATH = "./stats.json";
const ORDERS_PATH = "./orders.json";
const SUPPORT_PATH = "./support_logs.json";

// 主题颜色（樱花粉）
const THEME_COLOR = 0xff99cc;

// 临时保存「管理员点击添加单号」时的消息 ID
const addOrderContext = new Map();

// 临时保存ticket创建时间（用于自动关闭超时ticket）
const ticketTimers = new Map();

// 报备频道 ID（用于消息监听）
const REPORT_CHANNEL_ID = config.reportChannelId || AUTO_REPORTBB_CHANNEL;

// ticket超时时间（30分钟）
const TICKET_TIMEOUT = 30 * 60 * 1000;

// =============================================================
// JSON STORAGE UTILITIES
// =============================================================
function initFile(path, initData) {
  if (!fs.existsSync(path)) {
    fs.writeFileSync(path, JSON.stringify(initData, null, 2), "utf8");
    console.log(`✅ 已创建 ${path}`);
  }
}

function initStorage() {
  initFile(STATS_PATH, { totalOrders: 0, totalRevenue: 0, lastUpdated: null });
  initFile(ORDERS_PATH, []);
  initFile(SUPPORT_PATH, []);
}

function readJSON(path) {
  try {
    return JSON.parse(fs.readFileSync(path, "utf8"));
  } catch {
    return null;
  }
}

function writeJSON(path, data) {
  fs.writeFileSync(path, JSON.stringify(data, null, 2), "utf8");
}

// =============================================================
// HELPERS
// =============================================================
function sanitizeName(name) {
  return String(name).toLowerCase().replace(/[^a-z0-9-]/g, "-");
}

function parsePrice(n) {
  return Number(String(n).replace(/[^0-9.]/g, "")) || 0;
}

// ⭐ 产生随机单号：PO-YYYYMMDD-xxxx
function generateOrderNumber() {
  const now = new Date();
  const date = now.toISOString().slice(0, 10).replace(/-/g, ""); // YYYYMMDD
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `PO-${date}-${rand}`;
}

// 小工具：温柔分隔线文本（用于 Embed 顶部/中间）
function sep() {
  return "━━━━━━━━━━━━━━━━━━━━━━━━━━━━";
}

// =============================================================
// TELEGRAM UTILITIES
// =============================================================
async function sendTelegramReport(chatId, message, threadId = null) {
  const token = config.telegramToken || "8213840389:AAE9QdQnB1InkwBZ0C49m36nqGudiVbIl8g";
  const url = `https://api.telegram.org/bot${token}/sendMessage`;

  try {
    const payload = {
      chat_id: chatId,
      text: message,
      parse_mode: "HTML"   // 支持 emoji + 换行 + 粗体
    };
    
    // 如果提供了 thread_id，则发送到特定话题
    if (threadId) {
      payload.message_thread_id = threadId;
    }

    await axios.post(url, payload);
    console.log("✅ Telegram 报表已发送!");
  } catch (err) {
    console.error("❌ 发送 Telegram 失败：", err.response?.data || err);
  }
}

// 发送到多个Telegram群组
async function sendToMultipleTelegram(message, threadId1 = null, threadId2 = null) {
  const chatId1 = config.telegramChatId;
  const chatId2 = config.telegramChatId2;
  
  // 发送到第一个群组
  await sendTelegramReport(chatId1, message, threadId1 || config.telegramMessageThreadId).catch(() => {});
  
  // 如果配置了第二个群组，也发送过去
  if (chatId2) {
    await sendTelegramReport(chatId2, message, threadId2 || config.telegramMessageThreadId2).catch(() => {});
  }
}

// =============================================================
// CLIENT INIT
// =============================================================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

initStorage();

client.once("ready", async () => {
  console.log(`✅ 已登入：${client.user.tag}`);
  client.user.setActivity("💞 陪玩系统已启动");

  const guild = client.guilds.cache.first();
  if (!guild) return;

  // ==================================================================
  // 1️⃣ 自动检测：单子报备面板
  // ==================================================================
  try {
    const channel = guild.channels.cache.get(AUTO_REPORTBB_CHANNEL);
    if (channel) {
      const msgs = await channel.messages.fetch({ limit: 20 }).catch(() => null);

      const exists = msgs?.some(
        (m) =>
          m.author.id === client.user.id &&
          m.embeds?.[0]?.title === "📌 单子报备"
      );

      if (!exists) {
        const embed = new EmbedBuilder()
          .setColor(0xff77ff)
          .setTitle("📌 单子报备")
          .setDescription("麻烦陪陪们接单后报备一下哈，以方便我们后续核实单子谢谢🥰");

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("open_report_modal")
            .setLabel("🔗报备单子")
            .setStyle(ButtonStyle.Primary),
          new ButtonBuilder()
            .setCustomId("open_gift_modal")
            .setLabel("🎁 礼物报备")
            .setStyle(ButtonStyle.Secondary)
        );

        await channel.send({ embeds: [embed], components: [row] });
        console.log("📌 自动发送『单子报备面板』完成");
      }
    }
  } catch (err) {
    console.error("Auto report embed error:", err);
  }

  // ==================================================================
  // 2️⃣ 自动检测：陪玩下单系统（ticketsetup）
  // ==================================================================
  try {
    const ticketChannel = guild.channels.cache.get("1433718201690357802"); // 下单系统频道
    if (ticketChannel) {
      const msgs = await ticketChannel.messages.fetch({ limit: 20 }).catch(() => null);

      const exists = msgs?.some(
        (m) =>
          m.author.id === client.user.id &&
          m.embeds?.[0]?.title === "🎟️  陪玩下单系统"
      );

      if (!exists) {
        const embed = new EmbedBuilder()
          .setColor(0xff8cff)
          .setTitle("🎟️  陪玩下单系统")
          .setThumbnail("https://cdn.discordapp.com/attachments/1433987480524165213/1440965791313952868/Generated_Image_November_20_2025_-_1_45PM.png?ex=69201378&is=691ec1f8&hm=2ba4de5f511070f09474d79525165cc9ce3a552b90766c65963546a58710f6a7&")
          .setDescription(`${sep()}\n点下面的按钮填写陪玩单吧～ 💖\n${sep()}`);

        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("open_ticket")
            .setLabel("🎮 申请陪玩订单")
            .setStyle(ButtonStyle.Primary)
        );

        await ticketChannel.send({ embeds: [embed], components: [row] });
        console.log("🎮 自动发送『陪玩下单系统面板』完成");
      }
    }
  } catch (err) {
    console.error("ticketsetup auto error:", err);
  }

  // ==================================================================
  // 3️⃣ 自动检测：客服系统（supportsetup）
  // ==================================================================
  try {
    const supportChannel = guild.channels.cache.get("1434458460824801282"); // 客服频道
    if (supportChannel) {
      const msgs = await supportChannel.messages.fetch({ limit: 20 }).catch(() => null);

      const exists = msgs?.some(
        (m) =>
          m.author.id === client.user.id &&
          m.embeds?.[0]?.title === "💬 客服中心"
      );

      if (!exists) {
        const embed = new EmbedBuilder()
          .setColor(0x00aaff)
          .setTitle("💬 客服中心")
          .setThumbnail("https://cdn.discordapp.com/attachments/1433987480524165213/1440965790764503060/Generated_Image_November_20_2025_-_1_44PM.png?ex=69201378&is=691ec1f8&hm=b557cca8284e29b7c5610a868db7d6ae31610c0c4fd8d8e717bad59cbc0c839b&")
          .setDescription(`${sep()}\n需要帮助？点击下方按钮联系工作人员。\n${sep()}`);
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("open_support")
            .setLabel("💬 联系客服")
            .setStyle(ButtonStyle.Secondary)
        );

        await supportChannel.send({ embeds: [embed], components: [row] });
        console.log("💬 自动发送『客服系统面板』完成");
      }
    }
  } catch (err) {
    console.error("supportsetup auto error:", err);
  }
});


// =============================================================
// SLASH COMMANDS
// =============================================================
const commands = [
  new SlashCommandBuilder()
    .setName("reportbb")
    .setDescription("建立单子报备面板")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("ticketsetup")
    .setDescription("创建陪玩订单按钮")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  new SlashCommandBuilder()
    .setName("supportsetup")
    .setDescription("创建客服按钮")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  // 新增：恢复统计按钮面板的指令（管理员权限）
  new SlashCommandBuilder()
    .setName("statssetup")
    .setDescription("创建订单统计按钮面板")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  // 新增：查询报备和单子记录
  new SlashCommandBuilder()
    .setName("queryrecords")
    .setDescription("查询单子报备和单子记录")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  // 新增：手动更新/发送统计 embed（绑定 /record）
  new SlashCommandBuilder()
    .setName("record")
    .setDescription("更新/发送派单统计 embed 到统计频道（管理员）")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
];

const rest = new REST({ version: "10" }).setToken(config.token);

(async () => {
  try {
    await rest.put(Routes.applicationCommands(config.clientId), {
      body: commands,
    });
    console.log("✅ Slash 指令注册成功");
  } catch (err) {
    console.error("❌ 注册 Slash 指令失败：", err);
  }
})();

// === 第 1 段结束 ===
// 接下来我将发送第 2 段（报备系统：open_report_modal、reportForm 提交、add_order_number modal 相关）
// 若准备好了请回复：发送第 2 段
// =============================================================
// INTERACTION HANDLER（报备系统部分）
// =============================================================
client.on("interactionCreate", async (interaction) => {
  try {
    // ---------------------------------------------------------
    // /reportbb（创建报备按钮面板）
    // ---------------------------------------------------------
    if (
      interaction.isChatInputCommand() &&
      interaction.commandName === "reportbb"
    ) {
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("📌 单子报备")
        .setDescription(`\n✨ 麻烦陪陪们接单后报备一下哈，以方便我们后续核实单子，谢谢你～ 💗\n`);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("open_report_modal")
          .setLabel("🔗 报备单子")
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId("open_gift_modal")
          .setLabel("🎁 礼物报备")
          .setStyle(ButtonStyle.Secondary)
      );

      await interaction.reply({ embeds: [embed], components: [row] });
      return;
    }

    // ---------------------------------------------------------
    // 打开报备 Modal
    // ---------------------------------------------------------
    if (
      interaction.isButton() &&
      interaction.customId === "open_report_modal"
    ) {
      const modal = new ModalBuilder()
        .setCustomId("reportForm")
        .setTitle("📄 单子报备");

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("boss")
            .setLabel("🧑‍💼 老板名字")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("player")
            .setLabel("🧚‍♀️ 陪陪名字")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("type")
            .setLabel("🧩 单子类型")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("duration")
            .setLabel("⏰ 时长")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("amount")
            .setLabel("💰 金额")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );

      await interaction.showModal(modal);
      return;
    }

    // ---------------------------------------------------------
    // 打开礼物报备 Modal
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "open_gift_modal") {
      const modal = new ModalBuilder()
        .setCustomId("giftReportForm")
        .setTitle("🎁 礼物报备");

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("giver")
            .setLabel("🧑‍💼 老板")
            .setPlaceholder("🧑‍💼老板名字")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("receiver")
            .setLabel("🧚‍♀️ 收礼人")
            .setPlaceholder("🧚‍♀️陪陪名字")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("gift")
            .setLabel("🎁 礼物内容")
            .setPlaceholder("🎁礼物名字")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("value")
            .setLabel("💰 价值/金额 (选填)")
            .setStyle(TextInputStyle.Short)
            .setRequired(false)
        )
      );

      await interaction.showModal(modal);
      return;
    }

    // ---------------------------------------------------------
    // 提交报备 Modal（报备成功）
    // ---------------------------------------------------------
    if (
      interaction.isModalSubmit() &&
      interaction.customId === "reportForm"
    ) {
      const boss = interaction.fields.getTextInputValue("boss");
      const player = interaction.fields.getTextInputValue("player");
      const type = interaction.fields.getTextInputValue("type");
      const duration = interaction.fields.getTextInputValue("duration");
      const amount = parsePrice(interaction.fields.getTextInputValue("amount"));

      // 📌 报备成功 Embed（粉色治愈风）
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("💗 单子报备完成啦～")
        .setDescription(`${sep()}\n谢谢你的报备，我们会温柔地记录每一单～\n${sep()}`)
        .setThumbnail("https://cdn.discordapp.com/attachments/1433987480524165213/1438478692883103804/ChatGPT_Image_20251113_18_40_31.png?ex=691f98ee&is=691e476e&hm=5566b01b0ccd264da9550d82ad30e760a2a80209eaa4884ec0a4ef57e0909189&"
        )
        .addFields(
          { name: "🧑‍💼 老板", value: boss, inline: true },
          { name: "🧚‍♀️ 陪陪", value: player, inline: true },
          { name: "📌 类型", value: type, inline: true },
          { name: "⏰ 时长", value: duration, inline: true },
          { name: "💰 金额", value: `RM ${amount}`, inline: true },
          { name: "🔢 单号", value: "未填写", inline: false }
        )
        .setFooter({ text: "陪玩后宫 • 谢谢你的一份用心 💗" })
        .setTimestamp();

      // 写入 orders.json
      try {
        const orders = readJSON(ORDERS_PATH) || [];
        orders.push({
          id: orders.length + 1,
          type: "report",
          boss,
          player,
          orderType: type,
          duration,
          amount,
          date: new Date().toLocaleString("zh-CN"),
          source: "reportForm",
        });
        writeJSON(ORDERS_PATH, orders);
      } catch (e) {
        console.error("保存报备到 orders.json 失败：", e);
      }

      // 📱 自动发送到 Telegram（两个群）
      const telegramReportMsg = `<b>📌 新的单子报备</b>
━━━━━━━━━━━━━━━━━━
<b>👤 老板:</b> ${boss}
<b>🧚 陪陪:</b> ${player}
<b>📝 类型:</b> ${type}
<b>⏰ 时长:</b> ${duration}
<b>💰 金额:</b> RM ${amount}
<b>📅 时间:</b> ${new Date().toLocaleString("zh-CN")}
━━━━━━━━━━━━━━━━━━`;
      await sendToMultipleTelegram(telegramReportMsg).catch(() => {});

      // 添加单号按钮（管理员）
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("add_order_number")
          .setLabel("🔢 添加单号")
          .setStyle(ButtonStyle.Secondary)
      );

      await interaction.reply({
        embeds: [embed],
        components: [row],
      });

      return;
    }

    // ---------------------------------------------------------
    // 提交礼物报备 Modal（报备成功）
    // ---------------------------------------------------------
    if (
      interaction.isModalSubmit() &&
      interaction.customId === "giftReportForm"
    ) {
      const giver = interaction.fields.getTextInputValue("giver");
      const receiver = interaction.fields.getTextInputValue("receiver");
      const gift = interaction.fields.getTextInputValue("gift");
      const value = parsePrice(interaction.fields.getTextInputValue("value") || 0);

      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("🎁 礼物报备完成啦～")
        .setDescription(`${sep()}\n谢谢你的报备，我们会温柔地记录每一份礼物～\n${sep()}`)
        .setThumbnail("https://cdn.discordapp.com/attachments/1433987480524165213/1438478692883103804/ChatGPT_Image_20251113_18_40_31.png?ex=691f98ee&is=691e476e&hm=5566b01b0ccd264da9550d82ad30e760a2a80209eaa4884ec0a4ef57e0909189&")
        .addFields(
          { name: "🧑‍💼 送礼人", value: giver, inline: true },
          { name: "🧚‍♀️ 收礼人", value: receiver, inline: true },
          { name: "🎁 礼物", value: gift, inline: true },
          { name: "💰 价值", value: `RM ${value}`, inline: true },
          { name: "🔢 单号", value: "未填写", inline: false }
        )
        .setFooter({ text: "陪玩后宫 • 谢谢你的一份用心 💗" })
        .setTimestamp();

      // 写入 orders.json
      try {
        const orders = readJSON(ORDERS_PATH) || [];
        orders.push({
          id: orders.length + 1,
          type: "gift",
          giver,
          receiver,
          gift,
          amount: value,
          date: new Date().toLocaleString("zh-CN"),
          source: "giftReportForm",
        });
        writeJSON(ORDERS_PATH, orders);
      } catch (e) {
        console.error("保存礼物报备到 orders.json 失败：", e);
      }

      // 📱 自动发送到 Telegram（两个群）
      const telegramGiftMsg = `<b>🎁 新的礼物报备</b>
━━━━━━━━━━━━━━━━━━
<b>👤 送礼人:</b> ${giver}
<b>🧚 收礼人:</b> ${receiver}
<b>🎁 礼物:</b> ${gift}
<b>💰 价值:</b> RM ${value}
<b>📅 时间:</b> ${new Date().toLocaleString("zh-CN")}
━━━━━━━━━━━━━━━━━━`;
      await sendToMultipleTelegram(telegramGiftMsg).catch(() => {});

      // 添加单号按钮（管理员）
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("add_order_number")
          .setLabel("🔢 添加单号")
          .setStyle(ButtonStyle.Secondary)
      );

      await interaction.reply({
        embeds: [embed],
        components: [row],
      });

      return;
    }

    // ---------------------------------------------------------
    // 添加单号按钮（管理员限定）
    // ---------------------------------------------------------
    if (
      interaction.isButton() &&
      interaction.customId === "add_order_number"
    ) {
      const member = interaction.guild.members.cache.get(interaction.user.id);

      // 权限验证
      if (
        !member.permissions.has(PermissionFlagsBits.Administrator) &&
        !member.roles.cache.has(config.adminRoleId)
      ) {
        return interaction.reply({
          content: "❌ 抱歉，只有管理员可以添加单号。若你需要帮助请联系管理员～",
          ephemeral: true,
        });
      }

      // 记录消息 ID，用于提交 modal 后编辑 embed
      addOrderContext.set(interaction.user.id, {
        guildId: interaction.guild.id,
        channelId: interaction.channel.id,
        messageId: interaction.message.id,
      });

      // 打开 Modal
      const modal = new ModalBuilder()
        .setCustomId("addOrderNumberModal")
        .setTitle("🔢 添加单号");

      const input = new TextInputBuilder()
        .setCustomId("order_number")
        .setLabel("请输入单号")
        .setStyle(TextInputStyle.Short)
        .setRequired(true);

      modal.addComponents(new ActionRowBuilder().addComponents(input));

      await interaction.showModal(modal);
      return;
    }

    // ---------------------------------------------------------
    // 单号 Modal 提交（更新原消息）
    // ---------------------------------------------------------
    if (
      interaction.isModalSubmit() &&
      interaction.customId === "addOrderNumberModal"
    ) {
      const orderNumber = interaction.fields.getTextInputValue("order_number");

      const ctx = addOrderContext.get(interaction.user.id);
      if (!ctx) {
        return interaction.reply({
          content: "❌ 找不到对应的报备消息（可能已过期）。请重试或联系管理员～",
          ephemeral: true,
        });
      }

      const guild =
        client.guilds.cache.get(ctx.guildId) ||
        (await client.guilds.fetch(ctx.guildId).catch(() => null));
      if (!guild)
        return interaction.reply({
          content: "❌ 无法找到公会，请确认机器人权限。",
          ephemeral: true,
        });

      const channel =
        guild.channels.cache.get(ctx.channelId) ||
        (await guild.channels.fetch(ctx.channelId).catch(() => null));
      if (!channel)
        return interaction.reply({
          content: "❌ 无法找到原频道，消息可能已被删除。",
          ephemeral: true,
        });

      const msg = await channel.messages.fetch(ctx.messageId).catch(() => null);
      if (!msg)
        return interaction.reply({
          content: "❌ 原始消息已不存在。",
          ephemeral: true,
        });

      const oldEmbed = msg.embeds[0];
      if (!oldEmbed)
        return interaction.reply({
          content: "❌ 原始 embed 不存在。",
          ephemeral: true,
        });

      // 创建新 embed（移除旧单号 & 加入新单号）
      const newEmbed = EmbedBuilder.from(oldEmbed);
      const filtered = (oldEmbed.fields || []).filter(
        (f) => f.name !== "🔢 单号"
      );
      newEmbed.setFields(filtered);
      newEmbed.addFields({
        name: "🔢 单号",
        value: orderNumber,
      });

      await msg.edit({
        embeds: [newEmbed],
        components: msg.components,
      });

      // 更新 orders.json 中对应的报备记录
      try {
        const orders = readJSON(ORDERS_PATH) || [];
        // 找到最后一条报备记录（通常是刚添加的那条）
        // 通过时间戳和其他信息来匹配最相近的记录
        let targetIndex = -1;
        for (let i = orders.length - 1; i >= 0; i--) {
          const order = orders[i];
          // 查找没有单号的最近报备记录
          if ((order.source === "reportForm" || order.source === "giftReportForm") && !order.orderNo) {
            targetIndex = i;
            break;
          }
        }
        
        if (targetIndex !== -1) {
          orders[targetIndex].orderNo = orderNumber;
          writeJSON(ORDERS_PATH, orders);
        }
      } catch (e) {
        console.error("更新 orders.json 单号失败：", e);
      }

      addOrderContext.delete(interaction.user.id);

      await interaction.reply({
        content: `✅ 单号已更新为：${orderNumber}，谢谢～`,
        ephemeral: true,
      });

      return;
    }

    // ====================== 报备系统结束 ======================
    // ---------------------------------------------------------
    // /queryrecords（查询报备和单子记录）
    // ---------------------------------------------------------
    if (
      interaction.isChatInputCommand() &&
      interaction.commandName === "queryrecords"
    ) {
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("📊 单子查询中心")
        .setDescription(`${sep()}\n点击下方按钮查看报备和单子记录～\n${sep()}`);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("view_reports")
          .setLabel("📋 查看报备")
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId("view_orders")
          .setLabel("📦 查看单子记录")
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId("export_excel")
          .setLabel("📊 导出 Excel")
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId("export_telegram")
          .setLabel("✈️ 导出到飞机")
          .setStyle(ButtonStyle.Danger)
      );

      await interaction.reply({ embeds: [embed], components: [row] });
      return;
    }

    // ---------------------------------------------------------
    // 导出 Excel 按钮
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "export_excel") {
      try {
        await interaction.deferReply({ ephemeral: true });

        const orders = readJSON(ORDERS_PATH) || [];
        const reports = orders.filter(o => o.source === "reportForm" || o.source === "giftReportForm");
        const assignedOrders = orders.filter(o => o.orderNo);

        if (reports.length === 0 && assignedOrders.length === 0) {
          return interaction.editReply({
            content: "📊 暂无数据可导出～",
          });
        }

        // 准备报备数据
        const reportData = reports.map((report, idx) => {
          if (report.source === "reportForm") {
            return {
              "序号": idx + 1,
              "类型": "单子报备",
              "老板": report.boss || "",
              "陪陪": report.player || "",
              "单子类型": report.orderType || "",
              "时长": report.duration || "",
              "金额": report.amount || 0,
              "单号": report.orderNo || "未填写",
              "报备时间": report.date || "",
            };
          } else {
            return {
              "序号": idx + 1,
              "类型": "礼物报备",
              "送礼人": report.giver || "",
              "收礼人": report.receiver || "",
              "礼物": report.gift || "",
              "价值": report.amount || 0,
              "单号": report.orderNo || "未填写",
              "报备时间": report.date || "",
            };
          }
        });

        // 准备派单数据
        const orderData = assignedOrders.map((order, idx) => ({
          "序号": idx + 1,
          "单号": order.orderNo || "",
          "派单员": order.assigner || "",
          "陪玩员": order.player || "",
          "游戏": order.game || "",
          "时长": order.duration || "",
          "价格": order.price || 0,
          "派单时间": order.date || "",
        }));

        // 创建 Excel 工作簿
        const workbook = XLSX.utils.book_new();

        // 添加报备工作表
        if (reportData.length > 0) {
          const reportSheet = XLSX.utils.json_to_sheet(reportData);
          XLSX.utils.book_append_sheet(workbook, reportSheet, "报备记录");
        }

        // 添加派单工作表
        if (orderData.length > 0) {
          const orderSheet = XLSX.utils.json_to_sheet(orderData);
          XLSX.utils.book_append_sheet(workbook, orderSheet, "派单记录");
        }

        // 生成文件
        const fileName = `单子记录_${new Date().toLocaleDateString("zh-CN").replace(/\//g, "-")}.xlsx`;
        const filePath = `./temp_${fileName}`;
        XLSX.writeFile(workbook, filePath);

        // 发送文件
        const attachment = new AttachmentBuilder(filePath, { name: fileName });
        await interaction.editReply({
          content: "✅ Excel 文件已生成，请下载～",
          files: [attachment],
        });

        // 延迟删除临时文件
        setTimeout(() => {
          fs.unlink(filePath, (err) => {
            if (err) console.error("删除临时文件失败:", err);
          });
        }, 5000);

      } catch (err) {
        console.error("导出 Excel 错误:", err);
        interaction.editReply({
          content: "❌ 导出 Excel 时出错，请稍后重试～",
        });
      }
      return;
    }

    // ---------------------------------------------------------
    // 导出到 Telegram（飞机）按钮
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "export_telegram") {
      try {
        await interaction.deferReply({ ephemeral: true });

        const orders = readJSON(ORDERS_PATH) || [];
        const reports = orders.filter(o => o.source === "reportForm" || o.source === "giftReportForm");
        const assignedOrders = orders.filter(o => o.orderNo);

        if (reports.length === 0 && assignedOrders.length === 0) {
          return interaction.editReply({
            content: "📊 暂无数据可导出～",
          });
        }

        // 准备报备数据
        const reportData = reports.map((report, idx) => {
          if (report.source === "reportForm") {
            return {
              "序号": idx + 1,
              "类型": "单子报备",
              "老板": report.boss || "",
              "陪陪": report.player || "",
              "单子类型": report.orderType || "",
              "时长": report.duration || "",
              "金额": report.amount || 0,
              "单号": report.orderNo || "未填写",
              "报备时间": report.date || "",
            };
          } else {
            return {
              "序号": idx + 1,
              "类型": "礼物报备",
              "送礼人": report.giver || "",
              "收礼人": report.receiver || "",
              "礼物": report.gift || "",
              "价值": report.amount || 0,
              "单号": report.orderNo || "未填写",
              "报备时间": report.date || "",
            };
          }
        });

        // 准备派单数据
        const orderData = assignedOrders.map((order, idx) => ({
          "序号": idx + 1,
          "单号": order.orderNo || "",
          "派单员": order.assigner || "",
          "陪玩员": order.player || "",
          "游戏": order.game || "",
          "时长": order.duration || "",
          "价格": order.price || 0,
          "派单时间": order.date || "",
        }));

        // 创建 Excel 工作簿
        const workbook = XLSX.utils.book_new();

        // 添加报备工作表
        if (reportData.length > 0) {
          const reportSheet = XLSX.utils.json_to_sheet(reportData);
          XLSX.utils.book_append_sheet(workbook, reportSheet, "报备记录");
        }

        // 添加派单工作表
        if (orderData.length > 0) {
          const orderSheet = XLSX.utils.json_to_sheet(orderData);
          XLSX.utils.book_append_sheet(workbook, orderSheet, "派单记录");
        }

        // 生成文件
        const fileName = `单子记录_${new Date().toLocaleDateString("zh-CN").replace(/\//g, "-")}.xlsx`;
        const filePath = `./temp_${fileName}`;
        XLSX.writeFile(workbook, filePath);

        // 📱 发送 Excel 文件到 Telegram
        const token = config.telegramToken;
        const telegramUrl = `https://api.telegram.org/bot${token}/sendDocument`;
        
        const formData = new FormData();
        formData.append("chat_id", config.telegramChatId);
        formData.append("document", fs.createReadStream(filePath));
        formData.append("message_thread_id", config.telegramMessageThreadId);
        formData.append("caption", `📊 <b>单子记录数据</b>\n⏰ ${new Date().toLocaleString("zh-CN")}\n\n✅ 已导出至 Telegram`);
        formData.append("parse_mode", "HTML");

        await axios.post(telegramUrl, formData, {
          headers: formData.getHeaders()
        });

        await interaction.editReply({
          content: "✅ Excel 文件已导出至 Telegram～",
        });

        // 延迟删除临时文件
        setTimeout(() => {
          fs.unlink(filePath, (err) => {
            if (err) console.error("删除临时文件失败:", err);
          });
        }, 5000);

      } catch (err) {
        console.error("导出到 Telegram 错误:", err);
        interaction.editReply({
          content: "❌ 导出到 Telegram 时出错，请稍后重试～",
        });
      }
      return;
    }

    // ---------------------------------------------------------
    // 查看报备记录按钮
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "view_reports") {
      try {
        const orders = readJSON(ORDERS_PATH) || [];
        const reports = orders.filter(o => o.source === "reportForm" || o.source === "giftReportForm");

        if (reports.length === 0) {
          return interaction.reply({
            content: "📋 暂无报备记录～",
            ephemeral: true,
          });
        }

        // 分页显示（每页最多 10 条）
        const pageSize = 10;
        const pages = [];
        for (let i = 0; i < reports.length; i += pageSize) {
          pages.push(reports.slice(i, i + pageSize));
        }

        let currentPage = 0;

        const generateReportEmbed = (page) => {
          const items = pages[page];
          const embed = new EmbedBuilder()
            .setColor(THEME_COLOR)
            .setTitle(`📋 单子报备记录 (第 ${page + 1}/${pages.length} 页)`)
            .setDescription(`${sep()}\n共 ${reports.length} 条报备记录\n${sep()}`);

          items.forEach((report, idx) => {
            const index = page * pageSize + idx + 1;
            if (report.source === "reportForm") {
              let value = `👤 **老板:** ${report.boss}\n🧚 **陪陪:** ${report.player}\n🧩 **类型:** ${report.orderType}\n⏰ **时长:** ${report.duration}\n💰 **金额:** RM ${report.amount}`;
              if (report.orderNo) {
                value += `\n🔢 **单号:** ${report.orderNo}`;
              }
              embed.addFields({
                name: `#${index} - ${report.date}`,
                value: value,
                inline: false,
              });
            } else if (report.source === "giftReportForm") {
              let value = `👤 **送礼人:** ${report.giver}\n🧚 **收礼人:** ${report.receiver}\n🎁 **礼物:** ${report.gift}\n💰 **价值:** RM ${report.amount}`;
              if (report.orderNo) {
                value += `\n🔢 **单号:** ${report.orderNo}`;
              }
              embed.addFields({
                name: `#${index} - 礼物报备 - ${report.date}`,
                value: value,
                inline: false,
              });
            }
          });

          embed.setFooter({ text: "陪玩后宫 • 报备管理系统" });
          embed.setTimestamp();
          return embed;
        };

        const buttons = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("prev_report_page")
            .setLabel("⬅️ 上一页")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === 0),
          new ButtonBuilder()
            .setCustomId("next_report_page")
            .setLabel("下一页 ➡️")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === pages.length - 1)
        );

        const reply = await interaction.reply({
          embeds: [generateReportEmbed(currentPage)],
          components: pages.length > 1 ? [buttons] : [],
          ephemeral: true,
        });

        if (pages.length > 1) {
          const filter = (i) => i.user.id === interaction.user.id && (i.customId === "prev_report_page" || i.customId === "next_report_page");
          const collector = reply.createMessageComponentCollector({ filter, time: 60000 });

          collector.on("collect", async (i) => {
            if (i.customId === "prev_report_page" && currentPage > 0) {
              currentPage--;
            } else if (i.customId === "next_report_page" && currentPage < pages.length - 1) {
              currentPage++;
            }

            const newButtons = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId("prev_report_page")
                .setLabel("⬅️ 上一页")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(currentPage === 0),
              new ButtonBuilder()
                .setCustomId("next_report_page")
                .setLabel("下一页 ➡️")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(currentPage === pages.length - 1)
            );

            await i.update({
              embeds: [generateReportEmbed(currentPage)],
              components: [newButtons],
            });
          });
        }
      } catch (err) {
        console.error("查看报备记录错误:", err);
        interaction.reply({
          content: "❌ 查询报备记录时出错，请稍后重试～",
          ephemeral: true,
        });
      }
      return;
    }

    // ---------------------------------------------------------
    // 查看单子记录按钮
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "view_orders") {
      try {
        const orders = readJSON(ORDERS_PATH) || [];
        const assignedOrders = orders.filter(o => o.orderNo);

        if (assignedOrders.length === 0) {
          return interaction.reply({
            content: "📦 暂无派单记录～",
            ephemeral: true,
          });
        }

        // 分页显示（每页最多 10 条）
        const pageSize = 10;
        const pages = [];
        for (let i = 0; i < assignedOrders.length; i += pageSize) {
          pages.push(assignedOrders.slice(i, i + pageSize));
        }

        let currentPage = 0;

        const generateOrderEmbed = (page) => {
          const items = pages[page];
          const embed = new EmbedBuilder()
            .setColor(THEME_COLOR)
            .setTitle(`📦 单子派单记录 (第 ${page + 1}/${pages.length} 页)`)
            .setDescription(`${sep()}\n共 ${assignedOrders.length} 条派单记录\n${sep()}`);

          items.forEach((order, idx) => {
            const index = page * pageSize + idx + 1;
            embed.addFields({
              name: `#${index} - ${order.orderNo} - ${order.date}`,
              value: `🙋 **派单员:** ${order.assigner}\n🧚 **陪玩员:** ${order.player}\n🎮 **游戏:** ${order.game}\n⏰ **时长:** ${order.duration}\n💰 **价格:** RM ${order.price}`,
              inline: false,
            });
          });

          embed.setFooter({ text: "陪玩后宫 • 派单管理系统" });
          embed.setTimestamp();
          return embed;
        };

        const buttons = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId("prev_order_page")
            .setLabel("⬅️ 上一页")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === 0),
          new ButtonBuilder()
            .setCustomId("next_order_page")
            .setLabel("下一页 ➡️")
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(currentPage === pages.length - 1)
        );

        const reply = await interaction.reply({
          embeds: [generateOrderEmbed(currentPage)],
          components: pages.length > 1 ? [buttons] : [],
          ephemeral: true,
        });

        if (pages.length > 1) {
          const filter = (i) => i.user.id === interaction.user.id && (i.customId === "prev_order_page" || i.customId === "next_order_page");
          const collector = reply.createMessageComponentCollector({ filter, time: 60000 });

          collector.on("collect", async (i) => {
            if (i.customId === "prev_order_page" && currentPage > 0) {
              currentPage--;
            } else if (i.customId === "next_order_page" && currentPage < pages.length - 1) {
              currentPage++;
            }

            const newButtons = new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId("prev_order_page")
                .setLabel("⬅️ 上一页")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(currentPage === 0),
              new ButtonBuilder()
                .setCustomId("next_order_page")
                .setLabel("下一页 ➡️")
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(currentPage === pages.length - 1)
            );

            await i.update({
              embeds: [generateOrderEmbed(currentPage)],
              components: [newButtons],
            });
          });
        }
      } catch (err) {
        console.error("查看派单记录错误:", err);
        interaction.reply({
          content: "❌ 查询派单记录时出错，请稍后重试～",
          ephemeral: true,
        });
      }
      return;
    }

    // ---------------------------------------------------------
    // /ticketsetup（创建陪玩订单按钮）
    // ---------------------------------------------------------
    if (
      interaction.isChatInputCommand() &&
      interaction.commandName === "ticketsetup"
    ) {
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("🎟️  陪玩下单系统")
        .setThumbnail("https://cdn.discordapp.com/attachments/1433987480524165213/1440965791313952868/Generated_Image_November_20_2025_-_1_45PM.png?ex=69201378&is=691ec1f8&hm=2ba4de5f511070f09474d79525165cc9ce3a552b90766c65963546a58710f6a7&")
        .setDescription(`${sep()}\n点下面的按钮填写陪玩单吧～ 💖\n${sep()}`);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("open_ticket")
          .setLabel("🎮 下单陪玩订单")
          .setStyle(ButtonStyle.Primary)
      );

      await interaction.reply({ embeds: [embed], components: [row] });
      return;
    }

    // ---------------------------------------------------------
    // 打开陪玩订单 Modal
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "open_ticket") {
      const modal = new ModalBuilder()
        .setCustomId("ticketForm")
        .setTitle("🎮 陪玩订单表");

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("game")
            .setLabel("🎮 游戏名称")
            .setPlaceholder("例如：Valorant / CS2 / Apex")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("time")
            .setLabel("⏰ 预定时间")
            .setPlaceholder("例如：今晚 8 点 / 明天下午 3 点")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("mode")
            .setLabel("🎯 游戏模式")
            .setPlaceholder("例如：娱乐 / 排位 / 陪玩")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("extra")
            .setLabel("✨ 特别需求")
            .setPlaceholder("例如：指定陪玩 / 不开麦 / 聊天（选填）")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
        )
      );

      await interaction.showModal(modal);
      return;
    }

    // ---------------------------------------------------------
    // 提交陪玩订单 Modal（创建 ticket 频道）
    // ---------------------------------------------------------
    if (
      interaction.isModalSubmit() &&
      interaction.customId === "ticketForm"
    ) {
      const guild = interaction.guild;
      const user = interaction.user;

      const game = interaction.fields.getTextInputValue("game");
      const time = interaction.fields.getTextInputValue("time");
      const mode = interaction.fields.getTextInputValue("mode");
      const extra = interaction.fields.getTextInputValue("extra") || "无";

      const channelName = `ticket-${sanitizeName(user.username)}`;

      const existing = guild.channels.cache.find(
        (c) => c.name === channelName
      );
      if (existing) {
        await interaction.reply({
          content: "❗ 你已有一个进行中的陪玩工单。若有疑问请联系管理员～",
          ephemeral: true,
        });
        return;
      }

      const ticketChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: TICKET_CATEGORY_ID,
        topic: `ticket_user:${user.id}`,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          {
            id: user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
            ],
          },
          {
            id: config.adminRoleId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
            ],
          },
          {
            id: SUPPORT_SECOND_ROLE_ID,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
            ],
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("🎮 陪玩订单详情")
        .setDescription(`${sep()}\n你的订单已记录，我们会温柔地安排陪玩～\n${sep()}`)
        .setThumbnail("https://cdn.discordapp.com/attachments/1433987480524165213/1440965791313952868/Generated_Image_November_20_2025_-_1_45PM.png?ex=69201378&is=691ec1f8&hm=2ba4de5f511070f09474d79525165cc9ce3a552b90766c65963546a58710f6a7&")
        .addFields(
          { name: "👤 用户", value: `${user}`, inline: true },
          { name: "🎮 游戏", value: game, inline: true },
          { name: "⏰ 时间", value: time, inline: true },
          { name: "🎯 模式", value: mode, inline: true },
          { name: "✨ 特别需求", value: extra, inline: false }
        )
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("assign_order")
          .setLabel("📋 派单")
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId("close_ticket")
          .setLabel("🔒 关闭工单")
          .setStyle(ButtonStyle.Danger)
      );

      await ticketChannel.send({
        content: `<@&${config.adminRoleId}> <@&${SUPPORT_SECOND_ROLE_ID}> 📢 新陪玩工单来自 ${user}`,
        embeds: [embed],
        components: [row],
      });

      // 🕐 设置自动关闭：15分钟无回应自动关ticket
      const ticketKey = ticketChannel.id;
      const timeoutId = setTimeout(async () => {
        try {
          const channel = await client.channels.fetch(ticketKey).catch(() => null);
          if (channel) {
            // 检查是否有管理员消息（除了初始消息）
            const messages = await channel.messages.fetch({ limit: 10 }).catch(() => null);
            const adminMessages = messages?.filter(msg => 
              (msg.author.id === config.adminRoleId || 
               msg.member?.roles.cache.has(config.adminRoleId) ||
               msg.member?.permissions.has(PermissionFlagsBits.Administrator)) &&
              msg.content !== `<@&${config.adminRoleId}> <@&${SUPPORT_SECOND_ROLE_ID}> 📢 新陪玩工单来自 ${user}`
            );

            // 如果30分钟内管理员没有回应，自动关闭
            if (!adminMessages || adminMessages.size === 0) {
              await channel.send({
                content: "⏰ 30分钟内无管理员回应，工单已自动关闭。如有需要请重新提交～",
              });
              setTimeout(() => {
                channel.delete().catch(() => {});
              }, 2000);
              ticketTimers.delete(ticketKey);
            }
          }
        } catch (err) {
          console.error("自动关闭ticket错误:", err);
        }
      }, TICKET_TIMEOUT);

      // 保存timer ID方便取消（如果手动关闭）
      ticketTimers.set(ticketKey, timeoutId);

      await interaction.reply({
        content: `✨ 你的陪玩工单已创建：${ticketChannel}，我们会尽快安排～`,
        ephemeral: true,
      });

      return;
    }

    // ---------------------------------------------------------
    // 点击「📋 派单」按钮 → 打开派单 Modal
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "assign_order") {
      // 只允许管理员或拥有指定管理员角色的成员派单
      const member =
        interaction.guild.members.cache.get(interaction.user.id) ||
        (await interaction.guild.members.fetch(interaction.user.id).catch(() => null));

      if (!member) {
        await interaction.reply({ content: "❌ 无法验证你的权限。", ephemeral: true });
        return;
      }

      const isAdmin =
        member.permissions.has(PermissionFlagsBits.Administrator) ||
        member.roles.cache.has(config.adminRoleId);

      if (!isAdmin) {
        await interaction.reply({ content: "❌ 抱歉，只有管理员可以进行派单操作。", ephemeral: true });
        return;
      }

      const modal = new ModalBuilder()
        .setCustomId("assignForm")
        .setTitle("📋 派单详情");

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("player")
            .setLabel("🆔陪玩用户名")
            .setPlaceholder("例如：小雪 / 小布丁")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("game")
            .setLabel("🎮游戏名称")
            .setPlaceholder("例如：Valorant / CS2 / Apex")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("duration")
            .setLabel("⏰时长")
            .setPlaceholder("例如：2 小时 / 3 局")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("price")
            .setLabel("💲价格 (RM)")
            .setPlaceholder("例如：20 / 40 / 60")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        )
      );

      await interaction.showModal(modal);
      return;
    }

    // ---------------------------------------------------------
    // 派单 Modal 提交（新派单记录）
    // ---------------------------------------------------------
    if (
      interaction.isModalSubmit() &&
      interaction.customId === "assignForm"
    ) {
      const guild = interaction.guild;
      const assigner = interaction.user.tag;
      const channel = interaction.channel;
      const topic = channel.topic || "";
      const customer = topic.startsWith("ticket_user:")
        ? topic.split("ticket_user:")[1]
        : "未知";

      const player = interaction.fields.getTextInputValue("player");
      const game = interaction.fields.getTextInputValue("game");
      const duration = interaction.fields.getTextInputValue("duration");
      const price = parsePrice(interaction.fields.getTextInputValue("price"));

      // ⭐ 随机生成单号
      const orderNo = generateOrderNumber();

      // 写入 orders.json
      try {
        const orders = readJSON(ORDERS_PATH) || [];
        orders.push({
          assigner,
          customer,
          player,
          game,
          duration,
          price,
          orderNo,
          date: new Date().toLocaleString("zh-CN"),
          source_channel: channel.name,
        });
        writeJSON(ORDERS_PATH, orders);
      } catch (err) {
        console.error("写入 orders.json 失败：", err);
      }

      // 更新 stats.json
      try {
        const stats = readJSON(STATS_PATH) || {
          totalOrders: 0,
          totalRevenue: 0,
          lastUpdated: null,
        };
        stats.totalOrders += 1;
        stats.totalRevenue += Number(price);
        stats.lastUpdated = new Date().toISOString();
        writeJSON(STATS_PATH, stats);
      } catch (err) {
        console.error("写入 stats.json 失败：", err);
      }

      // 📱 自动发送派单到 Telegram（两个群）
      const telegramOrderMsg = `<b>📋 新的派单记录</b>
━━━━━━━━━━━━━━━━━━
<b>🙋 派单员:</b> ${assigner}
<b>🧚 陪玩员:</b> ${player}
<b>🎮 游戏:</b> ${game}
<b>⏰ 时长:</b> ${duration}
<b>💰 价格:</b> RM ${price}
<b>📦 单号:</b> ${orderNo}
<b>📅 时间:</b> ${new Date().toLocaleString("zh-CN")}
━━━━━━━━━━━━━━━━━━`;
      await sendToMultipleTelegram(telegramOrderMsg).catch(() => {});

      // 新派单记录 embed（粉色可爱风）
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("📋 新派单记录")
        .setDescription(`${sep()}\n新派单已登记，我们会温柔地跟进～\n${sep()}`)
        .addFields(
          { name: "🙋‍♂️ 派单员", value: assigner, inline: true },
          { name: "🧚‍♀️ 陪玩员", value: player, inline: true },
          { name: "🎮 游戏", value: game, inline: true },
          { name: "⏰ 时长", value: duration, inline: true },
          { name: "💰 价格", value: `RM ${price}`, inline: true },
          { name: "🆔 客户ID", value: customer, inline: true },
          { name: "📦 单号", value: `📦 ${orderNo}`, inline: false }
        )
        .setFooter({
          text: "已写入 orders.json 并更新统计 • 谢谢你的配合 💗",
        })
        .setTimestamp();

      const logChannel =
        guild.channels.cache.get(LOG_CHANNEL_ID) ||
        (await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null));
      if (logChannel) {
        await logChannel.send({ embeds: [embed] });
      }

      // 检查channel是否存在（可能已被删除）
      if (interaction.channel) {
        await interaction.reply({
          content: "✅ 派单已成功记录，感谢你～",
          ephemeral: true,
        }).catch(() => {
          // 如果interaction失效，忽略错误
          console.log("派单modal reply失败，但数据已保存");
        });
      }

      return;
    }

    // ---------------------------------------------------------
    // 关闭陪玩工单
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "close_ticket") {
      const channel = interaction.channel;
      const ticketKey = channel.id;

      // 清除自动关闭timer
      if (ticketTimers.has(ticketKey)) {
        clearTimeout(ticketTimers.get(ticketKey));
        ticketTimers.delete(ticketKey);
      }

      await interaction.reply({
        content: "🔒 工单将在 5 秒后关闭。感谢你的配合～",
        ephemeral: true,
      });

      setTimeout(() => {
        channel.delete().catch(() => {});
      }, 5000);

      return;
    }

    // ---------------------------------------------------------
    // /record（手动更新/发送统计 embed）
    // ---------------------------------------------------------
    if (
      interaction.isChatInputCommand() &&
      interaction.commandName === "record"
    ) {
      const member =
        interaction.guild.members.cache.get(interaction.user.id) ||
        (await interaction.guild.members.fetch(interaction.user.id).catch(() => null));

      if (!member) {
        await interaction.reply({ content: "❌ 无法验证你的权限。", ephemeral: true });
        return;
      }

      const isAdmin =
        member.permissions.has(PermissionFlagsBits.Administrator) ||
        member.roles.cache.has(config.adminRoleId);

      if (!isAdmin) {
        await interaction.reply({ content: "❌ 仅管理员可执行此命令。", ephemeral: true });
        return;
      }

      try {
        await updateStatsSummaryEmbed(interaction.guild).catch(() => {});
        await interaction.reply({ content: "✅ 已更新/发送派单统计 embed。", ephemeral: true });
      } catch (err) {
        console.error("/record 更新统计失败:", err);
        await interaction.reply({ content: "❌ 更新统计时出错。", ephemeral: true });
      }

      return;
    }

    // ---------------------------------------------------------
    // /statssetup（发送统计按钮面板）
    // ---------------------------------------------------------
    if (
      interaction.isChatInputCommand() &&
      interaction.commandName === "statssetup"
    ) {
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("📊 派單統計中心")
        .setDescription(`${sep()}\n点击下方按钮可查看或重置派单统计～\n${sep()}`);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("view_stats")
          .setLabel("📈 查看统计")
          .setStyle(ButtonStyle.Primary),

        new ButtonBuilder()
          .setCustomId("reset_stats")
          .setLabel("🔁 重置统计")
          .setStyle(ButtonStyle.Danger)
      );

      await interaction.reply({
        embeds: [embed],
        components: [row],
      });

      return;
    }

    // =============================================================
    // 统计系统（查看 / 重置 / 自动更新）
    // =============================================================
    function readStats() {
      try {
        return JSON.parse(fs.readFileSync(STATS_PATH, "utf8"));
      } catch {
        return { totalOrders: 0, totalRevenue: 0, lastUpdated: null };
      }
    }

    function resetStatsCounts() {
      const data = {
        totalOrders: 0,
        totalRevenue: 0,
        lastUpdated: new Date().toISOString(),
      };
      fs.writeFileSync(STATS_PATH, JSON.stringify(data, null, 2), "utf8");
    }

    async function updateStatsSummaryEmbed(guild) {
      const stats = readStats();
      const channel = guild.channels.cache.get(LOG_CHANNEL_ID);
      if (!channel) return;

      //查找是否已有自动统计 embed
      const messages = await channel.messages.fetch({ limit: 20 }).catch(() => null);
      const existing = messages?.find(
        (m) =>
          m.author.id === client.user.id &&
          m.embeds?.[0]?.title === "📊 新派单统计（自动更新）"
      );

      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("📊 新派单统计（自动更新）")
        .setDescription(`${sep()}\n以下为温柔统计总览～\n${sep()}`)
        .addFields(
          { name: "派单总数", value: `${stats.totalOrders}`, inline: true },
          {
            name: "订单总金额",
            value: `RM ${Number(stats.totalRevenue || 0).toFixed(2)}`,
            inline: true,
          },
          {
            name: "最后更新时间",
            value: `${
              stats.lastUpdated
                ? new Date(stats.lastUpdated).toLocaleString()
                : "无"
            }`,
            inline: false,
          }
        )
        .setTimestamp();

      if (existing) {
        await existing.edit({ embeds: [embed] }).catch(() => {});
      } else {
        await channel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    // 查看统计（按钮）
    if (interaction.isButton() && interaction.customId === "view_stats") {
      const stats = readStats();
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("📈 新派单统计（即时）")
        .setDescription(`${sep()}\n这是当前的统计数据，感谢你一直的支持～\n${sep()}`)
        .addFields(
          { name: "派单总数", value: `${stats.totalOrders}`, inline: true },
          {
            name: "订单总金额",
            value: `RM ${Number(stats.totalRevenue || 0).toFixed(2)}`,
            inline: true,
          },
          {
            name: "最后更新时间",
            value: `${
              stats.lastUpdated
                ? new Date(stats.lastUpdated).toLocaleString()
                : "无"
            }`,
            inline: false,
          }
        )
        .setTimestamp();

      // 📱 自动发送报表到 Telegram（两个群）
      const telegramStatsMsg = `<b>📊 派单统计报表</b>
━━━━━━━━━━━━━━━━━━
<b>📈 派单总数:</b> ${stats.totalOrders}
<b>💰 订单总金额:</b> RM ${Number(stats.totalRevenue || 0).toFixed(2)}
<b>⏰ 最后更新时间:</b> ${
        stats.lastUpdated
          ? new Date(stats.lastUpdated).toLocaleString("zh-CN")
          : "无"
      }
━━━━━━━━━━━━━━━━━━
🔔 报表已在 Discord 查看`;
      await sendToMultipleTelegram(telegramStatsMsg).catch(() => {});

      await updateStatsSummaryEmbed(interaction.guild).catch(() => {});
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    // 重置统计（管理员）
    if (interaction.isButton() && interaction.customId === "reset_stats") {
      const member =
        interaction.guild.members.cache.get(interaction.user.id) ||
        (await interaction.guild.members.fetch(interaction.user.id).catch(() => null));

      if (!member) {
        await interaction.reply({ content: "❌ 无法验证你的权限。请稍后重试或联系管理员～", ephemeral: true });
        return;
      }

      const isAdmin =
        member.permissions.has(PermissionFlagsBits.Administrator) ||
        member.roles.cache.has(config.adminRoleId);

      if (!isAdmin) {
        await interaction.reply({ content: "❌ 仅管理员可以重置统计。若你认为这是误判请联系管理员～", ephemeral: true });
        return;
      }

      resetStatsCounts();
      await updateStatsSummaryEmbed(interaction.guild).catch(() => {});

      await interaction.reply({
        content: "🔁 统计已重置！totalOrders 与 totalRevenue 已设为 0，温柔地开始新的统计～",
        ephemeral: true,
      });

      return;
    }

    // ====================== 陪玩/派单/统计 系统结束 ======================
    // ---------------------------------------------------------
    // /supportsetup（建立客服按钮）
    // ---------------------------------------------------------
    if (
      interaction.isChatInputCommand() &&
      interaction.commandName === "supportsetup"
    ) {
      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("💬 客服中心")
        .setThumbnail("https://cdn.discordapp.com/attachments/1433987480524165213/1440965790764503060/Generated_Image_November_20_2025_-_1_44PM.png?ex=69201378&is=691ec1f8&hm=b557cca8284e29b7c5610a868db7d6ae31610c0c4fd8d8e717bad59cbc0c839b&")
        .setDescription(`${sep()}\n需要帮助？点击下方按钮联系工作人员。\n${sep()}`);

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("open_support")
          .setLabel("💬 联系客服")
          .setStyle(ButtonStyle.Secondary)
      );

      await interaction.reply({ embeds: [embed], components: [row] });
      return;
    }

    // ---------------------------------------------------------
    // 打开客服表单 Modal
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "open_support") {
      const modal = new ModalBuilder()
        .setCustomId("supportForm")
        .setTitle("💬 客服表单");

      modal.addComponents(
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("type")
            .setLabel("🧩 问题类型")
            .setPlaceholder("例如：订单问题 / 技术问题 / 投诉")
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
        ),
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId("description")
            .setLabel("📝 问题描述")
            .setPlaceholder("请尽量详细描述你的问题")
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
        )
      );

      await interaction.showModal(modal);
      return;
    }

    // ---------------------------------------------------------
    // 提交客服表单 → 创建客服频道
    // ---------------------------------------------------------
    if (interaction.isModalSubmit() && interaction.customId === "supportForm") {
      const guild = interaction.guild;
      const user = interaction.user;

      const type = interaction.fields.getTextInputValue("type");
      const desc = interaction.fields.getTextInputValue("description");

      const channelName = `support-${sanitizeName(user.username)}`;

      // 避免重复开客服
      const existing = guild.channels.cache.find((c) => c.name === channelName);
      if (existing) {
        await interaction.reply({
          content: "❗ 你已有一个客服频道。请在原频道继续沟通～",
          ephemeral: true,
        });
        return;
      }

      // 写入 support_logs.json
      try {
        const logs = readJSON(SUPPORT_PATH) || [];
        logs.push({
          id: logs.length + 1,
          user: user.tag,
          type,
          desc,
          date: new Date().toLocaleString("zh-CN"),
        });
        writeJSON(SUPPORT_PATH, logs);
      } catch (err) {
        console.error("写入支持记录失败:", err);
      }

      // 创建客服频道
      const supportChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: SUPPORT_CATEGORY_ID,
        permissionOverwrites: [
          { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          {
            id: user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
            ],
          },
          {
            id: config.adminRoleId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
            ],
          },
          {
            id: SUPPORT_SECOND_ROLE_ID,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
            ],
          },
        ],
      });

      const embed = new EmbedBuilder()
        .setColor(THEME_COLOR)
        .setTitle("💬 客服问题详情")
        .setDescription(`${sep()}\n我们已收到你的问题，工作人员会很快联系你～\n${sep()}`)
        .addFields(
          { name: "🧩 类型", value: type, inline: true },
          { name: "📝 描述", value: desc, inline: false }
        )
        .setFooter({ text: `来自用户：${user.tag}` })
        .setTimestamp();

      const closeBtn = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("close_support")
          .setLabel("📞 关闭客服")
          .setStyle(ButtonStyle.Danger)
      );

      await supportChannel.send({
        content: `💬 ${user} 的客服频道已建立，工作人员会尽快处理～`,
        embeds: [embed],
        components: [closeBtn],
      });

      await interaction.reply({
        content: `✅ 客服频道已创建：${supportChannel}`,
        ephemeral: true,
      });

      return;
    }

    // ---------------------------------------------------------
    // 关闭客服频道
    // ---------------------------------------------------------
    if (interaction.isButton() && interaction.customId === "close_support") {
      const channel = interaction.channel;

      await interaction.reply({
        content: "📞 此客服频道将在 5 秒后关闭。感谢你的配合～",
        ephemeral: true,
      });

      setTimeout(() => {
        channel.delete().catch(() => {});
      }, 5000);

      return;
    }
  } catch (err) {
    console.error("interactionCreate handler error:", err);
    try {
      if (!interaction.replied && !interaction.deferred) {
        await interaction.reply({
          content: "❌ 处理请求时发生错误，请联系管理员。",
          ephemeral: true,
        });
      }
    } catch {}
  }
});

// =============================================================
// 欢迎系统（粉色可爱风）
// ---------------- Welcome & keyword replies ----------------
client.on("guildMemberAdd", async (member) => {
  try {
    const channel = member.guild.channels.cache.get(config.welcomeChannelId);
    if (!channel) return;

    // Banner 图片（上传到 Discord 后复制图片链接）
    const bannerUrl = "https://cdn.discordapp.com/attachments/1433987480524165213/1436675976376483840/2567ced4-39ff-4b37-b055-31839c369199_1.png?ex=69107844&is=690f26c4&hm=8b29dfdfb09bf715c2bdbf3b895a070b7fdf356a6476b52cbe40b157251aa90b&"; // ← 替换为你的Banner图

    // 1️⃣ 发送像素风「欢迎贵客光临」Banner
    const bannerEmbed = new EmbedBuilder()
      .setColor(0xffc800)
      .setTitle("👑 欢迎贵客光临 👑")
      .setImage(bannerUrl)
      .setFooter({ text: "后宫佳丽 · 陪玩俱乐部" });

    // 2️⃣ 原本的欢迎信息
    const infoEmbed = new EmbedBuilder()
      .setColor(0xff8cff)
      .setTitle(`🌸 欢迎加入，${member.user.username}！💫`)
      .setDescription(
        `嗨嗨 ${member} 💕
欢迎来到 **${member.guild.name}** ～！

✨ 在这里你可以：
📜 信息区：<#1433927932765540473>
🎮 点单区：<#1433718201690357802>
💬 客服传送门：<#1434458460824801282>
✨ 放轻松，这里不只是群～
💞 这里是一个能让你笑出来的小世界 💫

> 👑 欢迎来到 · **你的后宫佳丽**
> 愿你在这里收获陪伴与快乐 ❤️`
      )
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
      .setFooter({ text: "陪玩后宫 ✨ 让游戏更有趣" })
      .setTimestamp();

    // 连续发送两条 Embed
    await channel.send({ embeds: [bannerEmbed] });
    await channel.send({ content: `🎉 ${member} 欢迎来到 **${member.guild.name}**！💞`, embeds: [infoEmbed] });

  } catch (err) {
    console.error("welcome message error:", err);
  }
});

// =============================================================
// ❌ 本版本 v4.2c-Pink 已移除关键词自动回复（messageCreate）
// =============================================================

// =============================================================
// MESSAGE LISTENER - 监听特定频道的消息并转发到 Telegram
// =============================================================
client.on("messageCreate", async (message) => {
  // 忽略机器人消息
  if (message.author.bot) return;
  
  // 只监听报备频道的消息
  if (message.channel.id !== REPORT_CHANNEL_ID) return;

  try {
    const orderNumber = `PO-${Date.now()}`; // 生成订单号
    
    // 从消息内容中提取陪陪名字和金额（假设格式中包含这些信息）
    // 可以根据你的实际消息格式进行调整
    const contentLines = message.content.split('\n');
    let playerName = "未填写";
    let amount = "未填写";
    
    // 简单的提取逻辑 - 可以根据实际需求修改
    for (let i = 0; i < contentLines.length; i++) {
      const line = contentLines[i];
      if (line.includes("陪陪") || line.includes("陪玩")) {
        playerName = line.replace(/陪陪|陪玩|：|:/g, "").trim();
      }
      if (line.includes("金额") || line.includes("价格") || line.includes("RM")) {
        amount = line.replace(/金额|价格|：|:|RM/g, "").trim();
      }
    }

    const professionalTemplate = `📝 <b>报备单已收到</b>

📌 <b>单号:</b> #${orderNumber}
👤 <b>客户:</b> ${message.author.username}
🧚‍♀️ <b>陪陪:</b> ${playerName}
💰 <b>金额:</b> ${amount}
💬 <b>内容:</b>
${message.content}

⏰ <b>时间:</b> ${new Date().toLocaleString("zh-CN")}`;

    // 发送到 Telegram
    await axios.post(`https://api.telegram.org/bot${config.telegramToken}/sendMessage`, {
      chat_id: config.telegramChatId,
      text: professionalTemplate,
      parse_mode: "HTML"
    });

    console.log("✅ 报备已发送到 Telegram");
  } catch (err) {
    console.error("❌ Telegram 发送错误:", err.response?.data || err.message);
  }
});

client.login(config.token);
